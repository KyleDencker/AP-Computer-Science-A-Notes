/*    */ package piece;
/*    */ 
/*    */ import GameLogic.GameBoard;
/*    */ import GameLogic.GameMode;
/*    */ import java.awt.Toolkit;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ public class Bishop
/*    */   extends ChessPiece
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public Bishop(int x, int y, int side, String name)
/*    */     throws IOException
/*    */   {
/* 17 */     super(x, y, side);
/* 18 */     this.name = name;
/* 19 */     if (side == 1) {
/* 20 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("bishop.png")));
/*    */     } else {
/* 22 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("bbishop.png")));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isValid(int x, int y) {
/* 27 */     if (GameMode.isInBounds(x, y)) {
/* 28 */       if (Math.abs(getX() - x) == 0) return false;
/* 29 */       if (Math.abs(getX() - x) == Math.abs(getY() - y)) {
/* 30 */         int tempX = getX();
/* 31 */         int tempY = getY();
/*    */         
/* 33 */         if ((tempX - x > 0) && (tempY - y > 0)) {
/* 34 */           tempX--;
/* 35 */           tempY--;
/* 36 */         } else if ((tempX - x < 0) && (tempY - y > 0)) {
/* 37 */           tempX++;
/* 38 */           tempY--;
/* 39 */         } else if ((tempX - x < 0) && (tempY - y < 0)) {
/* 40 */           tempX++;
/* 41 */           tempY++;
/* 42 */         } else if ((tempX - x > 0) && (tempY - y < 0)) {
/* 43 */           tempX--;
/* 44 */           tempY++;
/*    */         }
/* 46 */         while ((tempX != x) && (tempY != y)) {
/* 47 */           if (GameBoard.isLocated(tempX, tempY) != -1) return false;
/* 48 */           if ((tempX - x > 0) && (tempY - y > 0)) {
/* 49 */             tempX--;
/* 50 */             tempY--;
/* 51 */           } else if ((tempX - x < 0) && (tempY - y > 0)) {
/* 52 */             tempX++;
/* 53 */             tempY--;
/* 54 */           } else if ((tempX - x < 0) && (tempY - y < 0)) {
/* 55 */             tempX++;
/* 56 */             tempY++;
/* 57 */           } else if ((tempX - x > 0) && (tempY - y < 0)) {
/* 58 */             tempX--;
/* 59 */             tempY++;
/*    */           }
/*    */         }
/* 62 */         if (GameBoard.isLocated(x, y) == -1) return true;
/* 63 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) return true;
/*    */       }
/*    */     }
/* 66 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean GetHasMoved()
/*    */   {
/* 72 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setHasMoved() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 84 */     return this.name;
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\Bishop.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */