/*    */ package piece;
/*    */ 
/*    */ import java.awt.Image;
/*    */ 
/*    */ public abstract class ChessPiece {
/*    */   private int x;
/*    */   private int y;
/*    */   private int side;
/*    */   private Image image;
/*    */   private int health;
/*    */   
/* 12 */   public ChessPiece(int x, int y, int side) { this.x = x;
/* 13 */     this.y = y;
/* 14 */     this.side = side;
/* 15 */     this.health = 0;
/*    */   }
/*    */   
/*    */   public void setCoord(int x, int y) {
/* 19 */     this.x = x;
/* 20 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void setImage(Image image) {
/* 24 */     this.image = image;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 28 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 32 */     return this.y;
/*    */   }
/*    */   
/*    */   public Image getImage() {
/* 36 */     return this.image;
/*    */   }
/*    */   
/*    */   public int getSide() {
/* 40 */     return this.side;
/*    */   }
/*    */   
/*    */   public boolean isPoison() {
/* 44 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isHeal() {
/* 48 */     return false;
/*    */   }
/*    */   
/*    */   public int getHealth() {
/* 52 */     return this.health;
/*    */   }
/*    */   
/*    */   public void addHealth() {
/* 56 */     this.health += 1;
/*    */   }
/*    */   
/*    */   public void heal() {
/* 60 */     this.health = 0;
/*    */   }
/*    */   
/*    */   public abstract boolean isValid(int paramInt1, int paramInt2);
/*    */   
/*    */   public abstract boolean GetHasMoved();
/*    */   
/*    */   public abstract void setHasMoved();
/*    */   
/*    */   public abstract String getName();
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\ChessPiece.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */