/*    */ package piece;
/*    */ 
/*    */ import GameLogic.GameBoard;
/*    */ import GameLogic.GameMode;
/*    */ import java.awt.Toolkit;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class Rook
/*    */   extends ChessPiece
/*    */ {
/*    */   private String name;
/*    */   private boolean hasMoved;
/*    */   
/*    */   public Rook(int x, int y, int side, String name)
/*    */     throws IOException
/*    */   {
/* 17 */     super(x, y, side);
/* 18 */     this.name = name;
/* 19 */     this.hasMoved = false;
/* 20 */     if (side == 1) {
/* 21 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("rook.png")));
/*    */     } else {
/* 23 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("brook.png")));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isValid(int x, int y) {
/* 28 */     if (GameMode.isInBounds(x, y)) {
/* 29 */       if ((getX() == x) && (getY() != y)) {
/* 30 */         int temp = getY();
/* 31 */         if (temp > y) {
/* 32 */           temp--;
/*    */         } else {
/* 34 */           temp++;
/*    */         }
/* 36 */         while (temp != y) {
/* 37 */           if (GameBoard.isLocated(x, temp) != -1) return false;
/* 38 */           if (temp > y) {
/* 39 */             temp--;
/*    */           } else {
/* 41 */             temp++;
/*    */           }
/*    */         }
/* 44 */         if (GameBoard.isLocated(x, y) == -1) return true;
/* 45 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) return true;
/*    */       }
/* 47 */       else if ((getX() != x) && (getY() == y)) {
/* 48 */         int temp = getX();
/* 49 */         if (temp > x) {
/* 50 */           temp--;
/*    */         } else {
/* 52 */           temp++;
/*    */         }
/* 54 */         while (temp != x) {
/* 55 */           if (GameBoard.isLocated(temp, y) != -1) return false;
/* 56 */           if (temp > x) {
/* 57 */             temp--;
/*    */           } else {
/* 59 */             temp++;
/*    */           }
/*    */         }
/* 62 */         if (GameBoard.isLocated(x, y) == -1) return true;
/* 63 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) return true;
/*    */       }
/*    */     }
/* 66 */     return false;
/*    */   }
/*    */   
/*    */   public boolean GetHasMoved()
/*    */   {
/* 71 */     return this.hasMoved;
/*    */   }
/*    */   
/*    */   public void setHasMoved()
/*    */   {
/* 76 */     this.hasMoved = true;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getName()
/*    */   {
/* 82 */     return this.name;
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\Rook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */