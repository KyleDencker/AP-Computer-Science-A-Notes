/*     */ package piece;
/*     */ 
/*     */ import GameLogic.GameBoard;
/*     */ import GameLogic.GameMode;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class Pawn
/*     */   extends ChessPiece
/*     */ {
/*     */   private String name;
/*     */   private boolean hasMoved;
/*     */   
/*     */   public Pawn(int x, int y, int side, String name)
/*     */     throws IOException
/*     */   {
/*  17 */     super(x, y, side);
/*  18 */     this.name = name;
/*  19 */     this.hasMoved = false;
/*  20 */     if (side == 1) {
/*  21 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("pawn.png")));
/*     */     } else {
/*  23 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("bpawn.png")));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isValid(int x, int y) {
/*  28 */     if (GameMode.isInBounds(x, y)) {
/*  29 */       if (getY() == y)
/*  30 */         return false;
/*  31 */       if (getSide() == 1) {
/*  32 */         if (this.hasMoved) {
/*  33 */           if (getY() - y == 1) {
/*  34 */             if (getX() == x) {
/*  35 */               if (GameBoard.isLocated(x, y) != -1)
/*  36 */                 return false;
/*  37 */               return true;
/*     */             }
/*  39 */             if (Math.abs(getX() - x) == 1) {
/*  40 */               if (GameBoard.isLocated(x, y) == -1)
/*  41 */                 return false;
/*  42 */               if (GameBoard.getPiece(x, y).getSide() != 
/*  43 */                 getSide()) {
/*  44 */                 return true;
/*     */               }
/*     */               
/*     */             }
/*     */           }
/*     */         }
/*  50 */         else if (getX() == x) {
/*  51 */           if (getY() - y == 1) {
/*  52 */             if (GameBoard.isLocated(x, y) != -1)
/*  53 */               return false;
/*  54 */             return true; }
/*  55 */           if (getY() - y == 2) {
/*  56 */             if (GameBoard.isLocated(x, y + 1) != -1)
/*  57 */               return false;
/*  58 */             if (GameBoard.isLocated(x, y) != -1)
/*  59 */               return false;
/*  60 */             return true;
/*     */           }
/*     */         } else {
/*  63 */           if (getY() - y != 1)
/*  64 */             return false;
/*  65 */           if (Math.abs(getX() - x) == 1) {
/*  66 */             if (GameBoard.isLocated(x, y) == -1)
/*  67 */               return false;
/*  68 */             if (GameBoard.getPiece(x, y).getSide() != 
/*  69 */               getSide()) {
/*  70 */               return true;
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/*  76 */       else if (this.hasMoved) {
/*  77 */         if (getY() - y == -1) {
/*  78 */           if (getX() == x) {
/*  79 */             if (GameBoard.isLocated(x, y) != -1)
/*  80 */               return false;
/*  81 */             return true;
/*     */           }
/*  83 */           if (Math.abs(getX() - x) == 1) {
/*  84 */             if (GameBoard.isLocated(x, y) == -1)
/*  85 */               return false;
/*  86 */             if (GameBoard.getPiece(x, y).getSide() != 
/*  87 */               getSide()) {
/*  88 */               return true;
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/*  94 */       else if (getX() == x) {
/*  95 */         if (getY() - y == -1) {
/*  96 */           if (GameBoard.isLocated(x, y) != -1)
/*  97 */             return false;
/*  98 */           return true; }
/*  99 */         if (getY() - y == -2) {
/* 100 */           if (GameBoard.isLocated(x, y - 1) != -1)
/* 101 */             return false;
/* 102 */           if (GameBoard.isLocated(x, y) != -1)
/* 103 */             return false;
/* 104 */           return true;
/*     */         }
/*     */       } else {
/* 107 */         if (getY() - y != -1)
/* 108 */           return false;
/* 109 */         if (Math.abs(getX() - x) == 1) {
/* 110 */           if (GameBoard.isLocated(x, y) == -1)
/* 111 */             return false;
/* 112 */           if (GameBoard.getPiece(x, y).getSide() != getSide()) {
/* 113 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 120 */     return false;
/*     */   }
/*     */   
/*     */   public boolean GetHasMoved()
/*     */   {
/* 125 */     return this.hasMoved;
/*     */   }
/*     */   
/*     */   public void setHasMoved()
/*     */   {
/* 130 */     this.hasMoved = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getName()
/*     */   {
/* 136 */     return this.name;
/*     */   }
/*     */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\Pawn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */