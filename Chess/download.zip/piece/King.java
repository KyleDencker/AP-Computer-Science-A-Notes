/*    */ package piece;
/*    */ 
/*    */ import GameLogic.GameBoard;
/*    */ import GameLogic.GameMode;
/*    */ import java.awt.Toolkit;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class King
/*    */   extends ChessPiece
/*    */ {
/*    */   private boolean hasMoved;
/*    */   private String name;
/*    */   
/*    */   public King(int x, int y, int side, String name)
/*    */     throws IOException
/*    */   {
/* 19 */     super(x, y, side);
/* 20 */     this.name = name;
/* 21 */     this.hasMoved = false;
/* 22 */     if (side == 1) {
/* 23 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("king.png")));
/*    */     } else {
/* 25 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("bking.png")));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isValid(int x, int y)
/*    */   {
/* 34 */     if (GameMode.isInBounds(x, y)) {
/* 35 */       if ((getX() == x) && (getY() == y)) { return false;
/*    */       }
/*    */       
/* 38 */       if ((Math.abs(getX() - x) <= 1) && (Math.abs(getY() - y) <= 1)) {
/* 39 */         if (GameBoard.isLocated(x, y) == -1) { return true;
/*    */         }
/* 41 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) { return true;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 67 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean GetHasMoved()
/*    */   {
/* 74 */     return this.hasMoved;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setHasMoved()
/*    */   {
/* 81 */     this.hasMoved = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 91 */     return this.name;
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\King.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */