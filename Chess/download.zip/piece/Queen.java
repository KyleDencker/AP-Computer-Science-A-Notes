/*     */ package piece;
/*     */ 
/*     */ import GameLogic.GameBoard;
/*     */ import GameLogic.GameMode;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ public class Queen
/*     */   extends ChessPiece
/*     */ {
/*     */   private boolean hasMoved;
/*     */   private String name;
/*     */   
/*     */   public Queen(int x, int y, int side, String name)
/*     */     throws IOException
/*     */   {
/*  18 */     super(x, y, side);
/*  19 */     this.name = name;
/*  20 */     this.hasMoved = false;
/*  21 */     if (side == 1) {
/*  22 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("queen.png")));
/*     */     } else
/*  24 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("bqueen.png")));
/*     */   }
/*     */   
/*     */   public boolean isValid(int x, int y) {
/*  28 */     if (GameMode.isInBounds(x, y))
/*     */     {
/*  30 */       if (Math.abs(getX() - x) == Math.abs(getY() - y)) {
/*  31 */         if (Math.abs(getX() - x) == 0) return false;
/*  32 */         int tempX = getX();
/*  33 */         int tempY = getY();
/*     */         
/*  35 */         if ((tempX - x > 0) && (tempY - y > 0)) {
/*  36 */           tempX--;
/*  37 */           tempY--;
/*  38 */         } else if ((tempX - x < 0) && (tempY - y > 0)) {
/*  39 */           tempX++;
/*  40 */           tempY--;
/*  41 */         } else if ((tempX - x < 0) && (tempY - y < 0)) {
/*  42 */           tempX++;
/*  43 */           tempY++;
/*  44 */         } else if ((tempX - x > 0) && (tempY - y < 0)) {
/*  45 */           tempX--;
/*  46 */           tempY++;
/*     */         }
/*  48 */         while ((tempX != x) && (tempY != y)) {
/*  49 */           if (GameBoard.isLocated(tempX, tempY) != -1) return false;
/*  50 */           if ((tempX - x > 0) && (tempY - y > 0)) {
/*  51 */             tempX--;
/*  52 */             tempY--;
/*  53 */           } else if ((tempX - x < 0) && (tempY - y > 0)) {
/*  54 */             tempX++;
/*  55 */             tempY--;
/*  56 */           } else if ((tempX - x < 0) && (tempY - y < 0)) {
/*  57 */             tempX++;
/*  58 */             tempY++;
/*  59 */           } else if ((tempX - x > 0) && (tempY - y < 0)) {
/*  60 */             tempX--;
/*  61 */             tempY++;
/*     */           }
/*     */         }
/*  64 */         if (GameBoard.isLocated(x, y) == -1) return true;
/*  65 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) return true;
/*  66 */       } else if ((getX() == x) && (getY() != y)) {
/*  67 */         int temp = getY();
/*  68 */         if (temp > y) {
/*  69 */           temp--;
/*     */         } else {
/*  71 */           temp++;
/*     */         }
/*  73 */         while (temp != y) {
/*  74 */           if (GameBoard.isLocated(x, temp) != -1) return false;
/*  75 */           if (temp > y) {
/*  76 */             temp--;
/*     */           } else {
/*  78 */             temp++;
/*     */           }
/*     */         }
/*  81 */         if (GameBoard.isLocated(x, y) == -1) return true;
/*  82 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) return true;
/*     */       }
/*  84 */       else if ((getX() != x) && (getY() == y))
/*     */       {
/*  86 */         int temp = getX();
/*  87 */         if (temp > x) {
/*  88 */           temp--;
/*     */         } else {
/*  90 */           temp++;
/*     */         }
/*  92 */         while (temp != x) {
/*  93 */           if (GameBoard.isLocated(temp, y) != -1) return false;
/*  94 */           if (temp > x) {
/*  95 */             temp--;
/*     */           } else {
/*  97 */             temp++;
/*     */           }
/*     */         }
/* 100 */         if (GameBoard.isLocated(x, y) == -1) return true;
/* 101 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) return true;
/*     */       }
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   public boolean GetHasMoved() {
/* 108 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setHasMoved() {}
/*     */   
/*     */   public String getName()
/*     */   {
/* 116 */     return this.name;
/*     */   }
/*     */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\Queen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */