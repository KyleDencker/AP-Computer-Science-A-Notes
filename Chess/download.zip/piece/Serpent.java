/*    */ package piece;
/*    */ 
/*    */ import GameLogic.GameBoard;
/*    */ import java.awt.Toolkit;
/*    */ 
/*    */ public class Serpent extends ChessPiece
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public Serpent(int x, int y, int side, String name)
/*    */   {
/* 12 */     super(x, y, side);
/* 13 */     this.name = name;
/* 14 */     if (side == 1) {
/* 15 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("serp.png")));
/*    */     } else {
/* 17 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("bserp.png")));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isValid(int x, int y)
/*    */   {
/* 24 */     if (GameLogic.GameMode.isInBounds(x, y)) {
/* 25 */       if (GameBoard.isLocated(x, y) == -1) {
/* 26 */         if ((Math.abs(x - getX()) == 0) && (Math.abs(y - getY()) == 0)) return false;
/* 27 */         if ((Math.abs(x - getX()) <= 2) && (Math.abs(y - getY()) == 0)) return true;
/* 28 */         if ((Math.abs(x - getX()) == 0) && (Math.abs(y - getY()) <= 2)) return true;
/*    */       }
/* 30 */       else if (GameBoard.getPiece(x, y).getSide() != getSide()) {
/* 31 */         if ((Math.abs(x - getX()) <= 2) && (Math.abs(y - getY()) == 0)) return true;
/* 32 */         if ((Math.abs(x - getX()) == 0) && (Math.abs(y - getY()) <= 2)) { return true;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 37 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean GetHasMoved()
/*    */   {
/* 45 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setHasMoved() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 60 */     return this.name;
/*    */   }
/*    */   
/*    */   public boolean isPoison() {
/* 64 */     return true;
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\Serpent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */