/*    */ package piece;
/*    */ 
/*    */ import GameLogic.GameBoard;
/*    */ import java.awt.Toolkit;
/*    */ 
/*    */ public class Knight extends ChessPiece
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public Knight(int x, int y, int side, String name)
/*    */   {
/* 12 */     super(x, y, side);
/* 13 */     this.name = name;
/* 14 */     if (side == 1) {
/* 15 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("knight.png")));
/*    */     } else {
/* 17 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("bknight.png")));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isValid(int x, int y)
/*    */   {
/* 24 */     if (GameLogic.GameMode.isInBounds(x, y)) {
/* 25 */       if (GameBoard.isLocated(x, y) == -1) {
/* 26 */         if ((Math.abs(x - getX()) == 2) && (Math.abs(y - getY()) == 1)) return true;
/* 27 */         if ((Math.abs(x - getX()) == 1) && (Math.abs(y - getY()) == 2)) return true;
/*    */       }
/* 29 */       else if (GameBoard.getPiece(x, y).getSide() != getSide()) {
/* 30 */         if ((Math.abs(x - getX()) == 2) && (Math.abs(y - getY()) == 1)) return true;
/* 31 */         if ((Math.abs(x - getX()) == 1) && (Math.abs(y - getY()) == 2)) { return true;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 36 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean GetHasMoved()
/*    */   {
/* 44 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setHasMoved() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 59 */     return this.name;
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\Knight.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */