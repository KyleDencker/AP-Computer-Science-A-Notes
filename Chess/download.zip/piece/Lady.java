/*    */ package piece;
/*    */ 
/*    */ import GameLogic.GameBoard;
/*    */ import java.awt.Toolkit;
/*    */ 
/*    */ public class Lady extends ChessPiece
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public Lady(int x, int y, int side, String name)
/*    */   {
/* 12 */     super(x, y, side);
/* 13 */     this.name = name;
/* 14 */     if (side == 1) {
/* 15 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("lady.png")));
/*    */     } else {
/* 17 */       setImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("blady.png")));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isValid(int x, int y)
/*    */   {
/* 24 */     if (GameLogic.GameMode.isInBounds(x, y)) {
/* 25 */       if ((getX() == x) && (getY() == y)) { return false;
/*    */       }
/*    */       
/* 28 */       if ((Math.abs(getX() - x) <= 1) && (Math.abs(getY() - y) <= 1)) {
/* 29 */         if (GameBoard.isLocated(x, y) == -1) { return true;
/*    */         }
/* 31 */         if (GameBoard.getPiece(x, y).getSide() != getSide()) { return true;
/*    */         }
/*    */       }
/*    */     }
/* 35 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean GetHasMoved()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setHasMoved() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 58 */     return this.name;
/*    */   }
/*    */   
/*    */   public boolean isHeal() {
/* 62 */     return true;
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\piece\Lady.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */