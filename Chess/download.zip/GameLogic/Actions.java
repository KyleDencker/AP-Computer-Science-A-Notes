/*     */ package GameLogic;
/*     */ 
/*     */ import NET.Client;
/*     */ import NET.Server;
/*     */ import graphics.PopUps;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Actions
/*     */   implements ActionListener
/*     */ {
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/*  25 */     if (e.getActionCommand().equals("New Game")) {
/*     */       try {
/*  27 */         PopUps.newGame();
/*     */       }
/*     */       catch (IOException e1) {
/*  30 */         e1.printStackTrace();
/*     */       }
/*  32 */     } else if (e.getActionCommand().equals("Open Game")) {
/*  33 */       PopUps.openGame();
/*  34 */     } else if (e.getActionCommand().equals("Save Game")) {
/*  35 */       PopUps.saveGame();
/*  36 */     } else if (e.getActionCommand().equals("Close")) {
/*  37 */       Chess.game.close();
/*  38 */     } else if (e.getActionCommand().equals("Standard Chess")) {
/*     */       try {
/*  40 */         PopUps.GameMode(1);
/*     */       }
/*     */       catch (IOException e1) {
/*  43 */         e1.printStackTrace();
/*     */       }
/*  45 */     } else if (e.getActionCommand().equals("Serpant-Old Lady")) {
/*     */       try {
/*  47 */         PopUps.GameMode(2);
/*     */       }
/*     */       catch (IOException e1) {
/*  50 */         e1.printStackTrace();
/*     */       }
/*  52 */     } else if (e.getActionCommand().equals("Keylay's Castle")) {
/*     */       try {
/*  54 */         PopUps.GameMode(3);
/*     */       }
/*     */       catch (IOException e1) {
/*  57 */         e1.printStackTrace();
/*     */       }
/*  59 */     } else if (e.getActionCommand().equals("Horde Chess")) {
/*     */       try {
/*  61 */         PopUps.GameMode(4);
/*     */       }
/*     */       catch (IOException e1) {
/*  64 */         e1.printStackTrace();
/*     */       }
/*  66 */     } else if (e.getActionCommand().equals("Displacement Chess")) {
/*     */       try {
/*  68 */         PopUps.GameMode(5);
/*     */       }
/*     */       catch (IOException e1) {
/*  71 */         e1.printStackTrace();
/*     */       }
/*  73 */     } else if (e.getActionCommand().equals("Backwards Chess")) {
/*     */       try {
/*  75 */         PopUps.GameMode(6);
/*     */       }
/*     */       catch (IOException e1) {
/*  78 */         e1.printStackTrace();
/*     */       }
/*  80 */     } else if (e.getActionCommand().equals("Pawns Game")) {
/*     */       try {
/*  82 */         PopUps.GameMode(7);
/*     */       }
/*     */       catch (IOException e1) {
/*  85 */         e1.printStackTrace();
/*     */       }
/*  87 */     } else if (e.getActionCommand().equals("Peasant's Revolt")) {
/*     */       try {
/*  89 */         PopUps.GameMode(8);
/*     */       }
/*     */       catch (IOException e1) {
/*  92 */         e1.printStackTrace();
/*     */       }
/*  94 */     } else if (e.getActionCommand().equals("Weak!")) {
/*     */       try {
/*  96 */         PopUps.GameMode(9);
/*     */       }
/*     */       catch (IOException e1) {
/*  99 */         e1.printStackTrace();
/*     */       }
/*     */     }
/* 102 */     else if (e.getActionCommand().equals("Host Game"))
/*     */     {
/* 104 */       GameBoard.server = new Server();
/*     */     }
/* 106 */     else if (e.getActionCommand().equals("Join Game")) {
/* 107 */       GameBoard.client = new Client();
/*     */     }
/* 109 */     else if (e.getActionCommand().equals("Disconnect")) {
/* 110 */       if (GameBoard.server != null) {
/* 111 */         GameBoard.server.disconnect();
/* 112 */         GameBoard.server = null;
/*     */       }
/*     */       
/* 115 */       if (GameBoard.client != null) {
/* 116 */         GameBoard.client.disconnect();
/* 117 */         GameBoard.client = null;
/*     */       }
/*     */       
/*     */     }
/* 121 */     else if (e.getActionCommand().equals("Display IP")) {
/* 122 */       PopUps.displayIP();
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 130 */       PopUps.errorMessage("Could not find this option.   Please report this");
/*     */     }
/*     */   }
/*     */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\GameLogic\Actions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */