/*    */ package GameLogic;
/*    */ 
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.event.MenuEvent;
/*    */ 
/*    */ public class MenuActions implements javax.swing.event.MenuListener
/*    */ {
/*    */   private int menu;
/*    */   
/*    */   public MenuActions()
/*    */   {
/* 13 */     this.menu = 1;
/*    */   }
/*    */   
/*    */   public MenuActions(int menu) {
/* 17 */     this.menu = menu;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void menuCanceled(MenuEvent e) {}
/*    */   
/*    */ 
/*    */   public void menuDeselected(MenuEvent e) {}
/*    */   
/*    */ 
/*    */   public void menuSelected(MenuEvent e)
/*    */   {
/* 30 */     JMenu temp = (JMenu)e.getSource();
/*    */     
/* 32 */     switch (this.menu)
/*    */     {
/*    */     case 1: 
/* 35 */       for (int i = 0; i < temp.getItemCount() - 2; i++) {
/* 36 */         if (GameBoard.isOnline) {
/* 37 */           temp.getItem(i).setEnabled(false);
/*    */         } else {
/* 39 */           temp.getItem(i).setEnabled(true);
/*    */         }
/*    */       }
/* 42 */       if (GameBoard.isOnline) {
/* 43 */         temp.getItem(3).setEnabled(true);
/*    */       } else {
/* 45 */         temp.getItem(3).setEnabled(false);
/*    */       }
/* 47 */       break;
/*    */     
/*    */ 
/*    */     case 2: 
/* 51 */       for (int i = 0; i < temp.getItemCount(); i++)
/*    */       {
/* 53 */         if (NET.Client.connected) {
/* 54 */           temp.getItem(i).setEnabled(false);
/*    */         } else {
/* 56 */           temp.getItem(i).setEnabled(true);
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */     
/*    */ 
/* 63 */     temp.repaint();
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\GameLogic\MenuActions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */