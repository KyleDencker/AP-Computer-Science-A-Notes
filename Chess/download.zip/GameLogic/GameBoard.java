/*     */ package GameLogic;
/*     */ 
/*     */ import NET.Client;
/*     */ import NET.Server;
/*     */ import graphics.PopUps;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JComponent;
/*     */ import piece.Bishop;
/*     */ import piece.ChessPiece;
/*     */ import piece.King;
/*     */ import piece.Knight;
/*     */ import piece.Lady;
/*     */ import piece.Pawn;
/*     */ import piece.Queen;
/*     */ import piece.Rook;
/*     */ import piece.Serpent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GameBoard
/*     */   extends JComponent
/*     */   implements MouseListener
/*     */ {
/*  31 */   private static int x = 40;
/*  32 */   private static int y = 40;
/*  33 */   private static int selected = -1;
/*     */   private static int lastX;
/*  35 */   private static int lastY; private static int lastDelete = -1;
/*     */   private static ChessPiece[] pieces;
/*  37 */   private static boolean gameStarted = false;
/*  38 */   public static int turn = 0;
/*     */   private static final long serialVersionUID = -2127938543571628440L;
/*  40 */   public static boolean isOnline = false;
/*     */   public static Server server;
/*     */   public static Client client;
/*     */   public static Image logo;
/*     */   
/*     */   public GameBoard() throws IOException
/*     */   {
/*  47 */     logo = Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png"));
/*  48 */     repaint();
/*  49 */     addMouseListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void paintComponent(Graphics g)
/*     */   {
/*  55 */     for (int i = 0; i < GameMode.getX(); i++) {
/*  56 */       for (int j = 0; j < GameMode.getY(); j++) {
/*  57 */         if (i % 2 == j % 2) {
/*  58 */           g.setColor(Color.GRAY);
/*     */         } else {
/*  60 */           g.setColor(Color.cyan);
/*     */         }
/*     */         
/*  63 */         g.fillRect(i * 50, j * 50, 50, 50);
/*     */       }
/*     */     }
/*  66 */     if (gameStarted) {
/*  67 */       for (int i = 0; i < pieces.length; i++) {
/*  68 */         if (pieces[i] != null) {
/*  69 */           g.drawImage(pieces[i].getImage(), pieces[i].getX() * 50, pieces[i].getY() * 50, this);
/*     */           
/*  71 */           if (pieces[i].getHealth() != 0) {
/*  72 */             g.setColor(Color.MAGENTA);
/*  73 */             for (int j = 0; j < 5; j++) {
/*  74 */               g.drawRect(pieces[i].getX() * 50 + j, pieces[i].getY() * 50 + j, 50 - 2 * j, 50 - 2 * j);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*  80 */         if (i == selected) {
/*  81 */           g.setColor(Color.blue);
/*  82 */           for (int j = 0; j < 5; j++) {
/*  83 */             g.drawRect(pieces[i].getX() * 50 + j, pieces[i].getY() * 50 + j, 50 - 2 * j, 50 - 2 * j);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  89 */       if (selected != -1) {
/*  90 */         g.setColor(Color.yellow);
/*  91 */         for (int i = 0; i < GameMode.getX(); i++) {
/*  92 */           for (int j = 0; j < GameMode.getY(); j++) {
/*  93 */             if (pieces[selected].isValid(i, j)) {
/*  94 */               for (int k = 0; k < 5; k++) {
/*  95 */                 g.drawRect(i * 50 + k, j * 50 + k, 50 - 2 * k, 50 - 2 * k);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 104 */       g.drawImage(logo, 50, 50, this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static int isLocated(int x, int y)
/*     */   {
/* 111 */     if (!GameMode.isInBounds(x, y)) return -1;
/* 112 */     for (int i = 0; i < pieces.length; i++)
/* 113 */       if ((pieces[i] != null) && 
/* 114 */         (pieces[i].getX() == x) && (pieces[i].getY() == y))
/* 115 */         return i;
/* 116 */     return -1;
/*     */   }
/*     */   
/*     */   public static boolean isThreat(int x, int y, int side) {
/* 120 */     for (int selected = 0; selected < pieces.length; selected++) {
/* 121 */       if ((pieces[selected] != null) && (side != pieces[selected].getSide()) && 
/* 122 */         (pieces[selected].isValid(x, y))) {
/* 123 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 128 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isThreat(ChessPiece king) {
/* 132 */     for (int selected = 0; selected < pieces.length; selected++) {
/* 133 */       if ((pieces[selected] != null) && (king.getSide() != pieces[selected].getSide()) && 
/* 134 */         (pieces[selected].isValid(king.getX(), king.getY()))) {
/* 135 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 140 */     return false;
/*     */   }
/*     */   
/*     */   public static ChessPiece getPiece(int x, int y) {
/* 144 */     for (int i = 0; i < pieces.length; i++)
/* 145 */       if ((pieces[i] != null) && 
/* 146 */         (pieces[i].getX() == x) && (pieces[i].getY() == y))
/* 147 */         return pieces[i];
/* 148 */     return null;
/*     */   }
/*     */   
/*     */   public static void DeletePiece(int index) {
/* 152 */     pieces[index] = null;
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent e)
/*     */   {
/* 157 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */ 
/*     */   public void mouseExited(MouseEvent e) {}
/*     */   
/*     */ 
/*     */   public void mousePressed(MouseEvent e) {}
/*     */   
/*     */ 
/*     */   public void mouseReleased(MouseEvent e)
/*     */   {
/*     */     try
/*     */     {
/* 174 */       if ((!isOnline) || ((Server.connected) && (turn == 1)) || ((Client.connected) && (turn == 2))) {
/* 175 */         chessMove(e.getX(), e.getY());
/*     */       }
/*     */     } catch (IOException e1) {
/* 178 */       e1.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void chessMove(int MX, int MY)
/*     */     throws IOException
/*     */   {
/* 186 */     if (gameStarted) {
/* 187 */       if (selected == -1) {
/* 188 */         if ((isLocated(MX / 50, MY / 50) != -1) && 
/* 189 */           (getPiece(MX / 50, MY / 50).getSide() == turn)) {
/* 190 */           selected = isLocated(MX / 50, MY / 50);
/* 191 */           if (Server.connected) server.sendMessage(MX + " " + MY);
/* 192 */           if (Client.connected) client.sendMessage(MX + " " + MY);
/*     */         }
/*     */       }
/*     */       else {
/* 196 */         if (pieces[selected].isValid(MX / 50, MY / 50))
/*     */         {
/*     */ 
/* 199 */           int offBoardX = -1;int offBoardY = -1;
/* 200 */           int place = isLocated(MX / 50, MY / 50);
/* 201 */           if (place != -1)
/*     */           {
/* 203 */             offBoardX = pieces[place].getX();
/* 204 */             offBoardY = pieces[place].getY();
/*     */             
/* 206 */             pieces[place].setCoord(-1, 64636);
/*     */           }
/*     */           
/* 209 */           lastX = pieces[selected].getX();
/* 210 */           lastY = pieces[selected].getY();
/*     */           
/* 212 */           pieces[selected].setCoord(MX / 50, MY / 50);
/* 213 */           pieces[selected].setHasMoved();
/* 214 */           if (pieces[selected].getName().equals("Black Pawn")) {
/* 215 */             if (pieces[selected].getY() == GameMode.getY() - 1) {
/*     */               try {
/* 217 */                 pieces[selected] = new Queen(pieces[selected].getX(), pieces[selected].getY(), 2, "Black Queen");
/*     */               } catch (IOException e1) {
/* 219 */                 e1.printStackTrace();
/*     */               }
/*     */             }
/* 222 */           } else if ((pieces[selected].getName().equals("White Pawn")) && 
/* 223 */             (pieces[selected].getY() == 0)) {
/*     */             try {
/* 225 */               pieces[selected] = new Queen(pieces[selected].getX(), pieces[selected].getY(), 1, "White Queen");
/*     */             } catch (IOException e1) {
/* 227 */               e1.printStackTrace();
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 232 */           boolean nextTurn = true;
/*     */           
/* 234 */           if (isThreat(pieces[(turn % 2)])) {
/* 235 */             pieces[selected].setCoord(lastX, lastY);
/*     */             
/*     */ 
/* 238 */             if (place != -1) {
/* 239 */               pieces[place].setCoord(offBoardX, offBoardY);
/*     */             }
/*     */             
/* 242 */             selected = -1;
/* 243 */             if (turn == 1) turn = 2; else
/* 244 */               turn = 1;
/* 245 */             PopUps.KingInCheck();
/* 246 */             nextTurn = false;
/*     */           }
/* 248 */           else if (isThreat(pieces[((turn + 1) % 2)])) { int side;
/*     */             int side;
/* 250 */             if (turn == 1) side = 2; else {
/* 251 */               side = 1;
/*     */             }
/* 253 */             if (!isCheckMate(side)) {
/* 254 */               repaint();
/* 255 */               PopUps.checkMate();
/*     */               try {
/* 257 */                 Thread.sleep(2000L);
/*     */               } catch (InterruptedException e1) {
/* 259 */                 e1.printStackTrace();
/*     */               }
/* 261 */               turn = 0;
/* 262 */               gameStarted = false;
/*     */             } else {
/* 264 */               PopUps.check();
/*     */             }
/*     */           }
/*     */           
/* 268 */           if (nextTurn) {
/* 269 */             if (pieces[selected].isPoison()) {
/* 270 */               for (int pX = pieces[selected].getX() - 1; pX < pieces[selected].getX() + 2; pX++) {
/* 271 */                 for (int pY = pieces[selected].getY() - 1; pY < pieces[selected].getY() + 2; pY++) {
/* 272 */                   int loc = isLocated(pX, pY);
/* 273 */                   if ((loc != -1) && 
/* 274 */                     (pieces[loc].getSide() != pieces[selected].getSide()) && (pieces[loc].getHealth() == 0)) {
/* 275 */                     pieces[loc].addHealth();
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 283 */             if (pieces[selected].isHeal()) {
/* 284 */               for (int pX = pieces[selected].getX() - 1; pX < pieces[selected].getX() + 2; pX++) {
/* 285 */                 for (int pY = pieces[selected].getY() - 1; pY < pieces[selected].getY() + 2; pY++) {
/* 286 */                   int loc = isLocated(pX, pY);
/* 287 */                   if ((loc != -1) && 
/* 288 */                     (pieces[loc].getSide() == pieces[selected].getSide())) {
/* 289 */                     pieces[loc].heal();
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 296 */             for (int ploc = 0; ploc < pieces.length; ploc++) {
/* 297 */               if (pieces[ploc] != null) {
/* 298 */                 if (pieces[ploc].getHealth() != 0) {
/* 299 */                   pieces[ploc].addHealth();
/*     */                 }
/*     */                 
/* 302 */                 if (pieces[ploc].getHealth() == 10) {
/* 303 */                   PopUps.poison(pieces[ploc].getName());
/*     */                   
/* 305 */                   if ((ploc == 0) || (ploc == 1))
/*     */                   {
/* 307 */                     repaint();
/* 308 */                     PopUps.checkMate();
/*     */                     try {
/* 310 */                       Thread.sleep(2000L);
/*     */                     } catch (InterruptedException e1) {
/* 312 */                       e1.printStackTrace();
/*     */                     }
/* 314 */                     if (server != null) server.sendMessage("Checkmate");
/* 315 */                     if (Client.connected) client.sendMessage("Checkmate");
/* 316 */                     turn = 0;
/* 317 */                     gameStarted = false;
/*     */                   }
/*     */                   
/*     */ 
/* 321 */                   DeletePiece(ploc);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 326 */           if (Server.connected) server.sendMessage(MX + " " + MY);
/* 327 */           if (Client.connected) client.sendMessage(MX + " " + MY);
/* 328 */           selected = -1;
/* 329 */           if (turn == 1) { turn = 2;
/* 330 */           } else if (turn == 2) turn = 1;
/*     */         } else {
/* 332 */           if (Server.connected) server.sendMessage(MX + " " + MY);
/* 333 */           if (Client.connected) client.sendMessage(MX + " " + MY);
/* 334 */           selected = -1;
/*     */         }
/* 336 */         lastDelete = -1;
/*     */       }
/*     */       
/*     */ 
/* 340 */       if (isLocated(-1, 64636) != -1) {
/* 341 */         DeletePiece(isLocated(-1, 64636));
/*     */       }
/* 343 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isCheckMate(int side)
/*     */   {
/* 351 */     for (int i = 0; i < pieces.length; i++) {
/* 352 */       if ((pieces[i] != null) && 
/* 353 */         (pieces[i].getSide() == side)) {
/* 354 */         int tempX = pieces[i].getX();
/* 355 */         int tempY = pieces[i].getY();
/* 356 */         for (int x = 0; x < GameMode.getX(); x++) {
/* 357 */           for (int y = 0; y < GameMode.getY(); y++) {
/* 358 */             if (pieces[i].isValid(x, y)) {
/* 359 */               int offBoardX = -1;int offBoardY = -1;
/* 360 */               int place = isLocated(x, y);
/* 361 */               if (place != -1) {
/* 362 */                 offBoardX = pieces[place].getX();
/* 363 */                 offBoardY = pieces[place].getY();
/* 364 */                 pieces[place].setCoord(-1, 64636);
/*     */               }
/* 366 */               pieces[i].setCoord(x, y);
/* 367 */               if (!isThreat(pieces[(side % 2)])) {
/* 368 */                 pieces[i].setCoord(tempX, tempY);
/* 369 */                 if (place != -1) {
/* 370 */                   pieces[place].setCoord(offBoardX, offBoardY);
/*     */                 }
/* 372 */                 return true;
/*     */               }
/* 374 */               pieces[i].setCoord(tempX, tempY);
/* 375 */               if (place != -1) {
/* 376 */                 pieces[place].setCoord(offBoardX, offBoardY);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 385 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void newGame(int mode)
/*     */     throws IOException
/*     */   {
/* 393 */     turn = 1;
/* 394 */     switch (mode) {
/*     */     case 1: 
/* 396 */       pieces = new ChessPiece[32];
/* 397 */       pieces[0] = new King(4, 0, 2, "Black King");
/* 398 */       pieces[1] = new King(4, 7, 1, "White King");
/* 399 */       pieces[2] = new Knight(1, 0, 2, "Black Knight");
/* 400 */       pieces[3] = new Knight(6, 0, 2, "Black Knight");
/* 401 */       pieces[4] = new Rook(0, 0, 2, "Black Rook");
/* 402 */       pieces[5] = new Rook(7, 0, 2, "Black Rook");
/* 403 */       pieces[6] = new Knight(1, 7, 1, "white Knight");
/* 404 */       pieces[7] = new Knight(6, 7, 1, "White Knight");
/* 405 */       pieces[8] = new Rook(0, 7, 1, "White Rook");
/* 406 */       pieces[9] = new Rook(7, 7, 1, "White Rook");
/* 407 */       pieces[10] = new Bishop(2, 0, 2, "Black Bishop");
/* 408 */       pieces[11] = new Bishop(5, 0, 2, "Black Bishop");
/* 409 */       pieces[12] = new Bishop(2, 7, 1, "White Bishop");
/* 410 */       pieces[13] = new Bishop(5, 7, 1, "White Bishop");
/* 411 */       pieces[14] = new Pawn(0, 6, 1, "White Pawn");
/* 412 */       pieces[15] = new Pawn(1, 6, 1, "White Pawn");
/* 413 */       pieces[16] = new Pawn(2, 6, 1, "White Pawn");
/* 414 */       pieces[17] = new Pawn(3, 6, 1, "White Pawn");
/* 415 */       pieces[18] = new Pawn(4, 6, 1, "White Pawn");
/* 416 */       pieces[19] = new Pawn(5, 6, 1, "White Pawn");
/* 417 */       pieces[20] = new Pawn(6, 6, 1, "White Pawn");
/* 418 */       pieces[21] = new Pawn(7, 6, 1, "White Pawn");
/* 419 */       pieces[23] = new Pawn(0, 1, 2, "Black Pawn");
/* 420 */       pieces[24] = new Pawn(1, 1, 2, "Black Pawn");
/* 421 */       pieces[25] = new Pawn(2, 1, 2, "Black Pawn");
/* 422 */       pieces[26] = new Pawn(3, 1, 2, "Black Pawn");
/* 423 */       pieces[27] = new Pawn(4, 1, 2, "Black Pawn");
/* 424 */       pieces[28] = new Pawn(5, 1, 2, "Black Pawn");
/* 425 */       pieces[29] = new Pawn(6, 1, 2, "Black Pawn");
/* 426 */       pieces[30] = new Pawn(7, 1, 2, "Black Pawn");
/* 427 */       pieces[31] = new Queen(3, 0, 2, "Black Queen");
/* 428 */       pieces[22] = new Queen(3, 7, 1, "White Queen");
/* 429 */       break;
/*     */     
/*     */     case 2: 
/* 432 */       pieces = new ChessPiece[40];
/* 433 */       pieces[0] = new King(5, 0, 2, "Black King");
/* 434 */       pieces[1] = new King(5, 9, 1, "White King");
/* 435 */       pieces[2] = new Knight(2, 0, 2, "Black Knight");
/* 436 */       pieces[3] = new Knight(7, 0, 2, "Black Knight");
/* 437 */       pieces[4] = new Rook(1, 0, 2, "Black Rook");
/* 438 */       pieces[5] = new Rook(8, 0, 2, "Black Rook");
/* 439 */       pieces[6] = new Knight(2, 9, 1, "white Knight");
/* 440 */       pieces[7] = new Knight(7, 9, 1, "White Knight");
/* 441 */       pieces[8] = new Rook(1, 9, 1, "White Rook");
/* 442 */       pieces[9] = new Rook(8, 9, 1, "White Rook");
/* 443 */       pieces[10] = new Bishop(3, 0, 2, "Black Bishop");
/* 444 */       pieces[11] = new Bishop(6, 0, 2, "Black Bishop");
/* 445 */       pieces[12] = new Bishop(3, 9, 1, "White Bishop");
/* 446 */       pieces[13] = new Bishop(6, 9, 1, "White Bishop");
/* 447 */       pieces[14] = new Pawn(1, 8, 1, "White Pawn");
/* 448 */       pieces[15] = new Pawn(2, 8, 1, "White Pawn");
/* 449 */       pieces[16] = new Pawn(3, 8, 1, "White Pawn");
/* 450 */       pieces[17] = new Pawn(4, 8, 1, "White Pawn");
/* 451 */       pieces[18] = new Pawn(5, 8, 1, "White Pawn");
/* 452 */       pieces[19] = new Pawn(6, 8, 1, "White Pawn");
/* 453 */       pieces[20] = new Pawn(7, 8, 1, "White Pawn");
/* 454 */       pieces[21] = new Pawn(8, 8, 1, "White Pawn");
/* 455 */       pieces[23] = new Pawn(1, 1, 2, "Black Pawn");
/* 456 */       pieces[24] = new Pawn(2, 1, 2, "Black Pawn");
/* 457 */       pieces[25] = new Pawn(3, 1, 2, "Black Pawn");
/* 458 */       pieces[26] = new Pawn(4, 1, 2, "Black Pawn");
/* 459 */       pieces[27] = new Pawn(5, 1, 2, "Black Pawn");
/* 460 */       pieces[28] = new Pawn(6, 1, 2, "Black Pawn");
/* 461 */       pieces[29] = new Pawn(7, 1, 2, "Black Pawn");
/* 462 */       pieces[30] = new Pawn(8, 1, 2, "Black Pawn");
/* 463 */       pieces[31] = new Queen(4, 0, 2, "Black Queen");
/* 464 */       pieces[22] = new Queen(4, 9, 1, "White Queen");
/* 465 */       pieces[32] = new Pawn(0, 8, 1, "White Pawn");
/* 466 */       pieces[33] = new Pawn(9, 8, 1, "White Pawn");
/* 467 */       pieces[34] = new Pawn(0, 1, 2, "Black Pawn");
/* 468 */       pieces[35] = new Pawn(9, 1, 2, "Black Pawn");
/* 469 */       pieces[36] = new Serpent(0, 0, 2, "Black Serpent");
/* 470 */       pieces[37] = new Lady(9, 0, 2, "Black Serpent");
/* 471 */       pieces[38] = new Serpent(0, 9, 1, "White Serpent");
/* 472 */       pieces[39] = new Lady(9, 9, 1, "White Serpent");
/* 473 */       break;
/*     */     case 3: 
/* 475 */       pieces = new ChessPiece[56];
/* 476 */       pieces[0] = new King(4, 0, 2, "Black King");
/* 477 */       pieces[1] = new King(4, 13, 1, "White King");
/* 478 */       pieces[2] = new Knight(1, 0, 2, "Black Knight");
/* 479 */       pieces[3] = new Knight(6, 0, 2, "Black Knight");
/* 480 */       pieces[4] = new Rook(0, 0, 2, "Black Rook");
/* 481 */       pieces[5] = new Rook(7, 0, 2, "Black Rook");
/* 482 */       pieces[6] = new Knight(1, 13, 1, "white Knight");
/* 483 */       pieces[7] = new Knight(6, 13, 1, "White Knight");
/* 484 */       pieces[8] = new Rook(0, 13, 1, "White Rook");
/* 485 */       pieces[9] = new Rook(7, 13, 1, "White Rook");
/* 486 */       pieces[10] = new Bishop(2, 0, 2, "Black Bishop");
/* 487 */       pieces[11] = new Bishop(5, 0, 2, "Black Bishop");
/* 488 */       pieces[12] = new Bishop(2, 13, 1, "White Bishop");
/* 489 */       pieces[13] = new Bishop(5, 13, 1, "White Bishop");
/* 490 */       pieces[14] = new Pawn(0, 9, 1, "White Pawn");
/* 491 */       pieces[15] = new Pawn(1, 10, 1, "White Pawn");
/* 492 */       pieces[16] = new Pawn(2, 11, 1, "White Pawn");
/* 493 */       pieces[17] = new Pawn(3, 12, 1, "White Pawn");
/* 494 */       pieces[18] = new Pawn(4, 12, 1, "White Pawn");
/* 495 */       pieces[19] = new Pawn(5, 11, 1, "White Pawn");
/* 496 */       pieces[20] = new Pawn(6, 10, 1, "White Pawn");
/* 497 */       pieces[21] = new Pawn(7, 9, 1, "White Pawn");
/* 498 */       pieces[23] = new Pawn(0, 4, 2, "Black Pawn");
/* 499 */       pieces[24] = new Pawn(1, 3, 2, "Black Pawn");
/* 500 */       pieces[25] = new Pawn(2, 2, 2, "Black Pawn");
/* 501 */       pieces[26] = new Pawn(3, 1, 2, "Black Pawn");
/* 502 */       pieces[27] = new Pawn(4, 1, 2, "Black Pawn");
/* 503 */       pieces[28] = new Pawn(5, 2, 2, "Black Pawn");
/* 504 */       pieces[29] = new Pawn(6, 3, 2, "Black Pawn");
/* 505 */       pieces[30] = new Pawn(7, 4, 2, "Black Pawn");
/* 506 */       pieces[31] = new Queen(3, 0, 2, "Black Queen");
/* 507 */       pieces[22] = new Queen(3, 13, 1, "White Queen");
/* 508 */       pieces[32] = new Bishop(2, 1, 2, "Black Bishop");
/* 509 */       pieces[33] = new Bishop(5, 1, 2, "Black Bishop");
/* 510 */       pieces[34] = new Bishop(2, 12, 1, "White Bishop");
/* 511 */       pieces[35] = new Bishop(5, 12, 1, "White Bishop");
/* 512 */       pieces[36] = new Knight(1, 1, 2, "Black Knight");
/* 513 */       pieces[37] = new Knight(6, 1, 2, "Black Knight");
/* 514 */       pieces[38] = new Rook(0, 1, 2, "Black Rook");
/* 515 */       pieces[39] = new Rook(7, 1, 2, "Black Rook");
/* 516 */       pieces[40] = new Knight(1, 12, 1, "white Knight");
/* 517 */       pieces[41] = new Knight(6, 12, 1, "White Knight");
/* 518 */       pieces[42] = new Rook(0, 12, 1, "White Rook");
/* 519 */       pieces[43] = new Rook(7, 12, 1, "White Rook");
/* 520 */       pieces[44] = new Knight(1, 2, 2, "Black Knight");
/* 521 */       pieces[45] = new Knight(6, 2, 2, "Black Knight");
/* 522 */       pieces[46] = new Rook(0, 2, 2, "Black Rook");
/* 523 */       pieces[47] = new Rook(7, 2, 2, "Black Rook");
/* 524 */       pieces[48] = new Knight(1, 11, 1, "white Knight");
/* 525 */       pieces[49] = new Knight(6, 11, 1, "White Knight");
/* 526 */       pieces[50] = new Rook(0, 11, 1, "White Rook");
/* 527 */       pieces[51] = new Rook(7, 11, 1, "White Rook");
/* 528 */       pieces[52] = new Rook(0, 10, 1, "White Rook");
/* 529 */       pieces[53] = new Rook(7, 10, 1, "White Rook");
/* 530 */       pieces[54] = new Rook(0, 3, 2, "Black Rook");
/* 531 */       pieces[55] = new Rook(7, 3, 2, "Black Rook");
/* 532 */       break;
/*     */     case 4: 
/* 534 */       pieces = new ChessPiece[48];
/* 535 */       pieces[0] = new King(4, 0, 2, "Black King");
/* 536 */       pieces[1] = new King(4, 7, 1, "White King");
/* 537 */       pieces[2] = new Knight(1, 0, 2, "Black Knight");
/* 538 */       pieces[3] = new Knight(6, 0, 2, "Black Knight");
/* 539 */       pieces[4] = new Rook(0, 0, 2, "Black Rook");
/* 540 */       pieces[5] = new Rook(7, 0, 2, "Black Rook");
/* 541 */       pieces[6] = new Pawn(1, 7, 1, "white Pawn");
/* 542 */       pieces[7] = new Pawn(6, 7, 1, "White Pawn");
/* 543 */       pieces[8] = new Pawn(0, 7, 1, "White Pawn");
/* 544 */       pieces[9] = new Pawn(7, 7, 1, "White Pawn");
/* 545 */       pieces[10] = new Bishop(2, 0, 2, "Black Bishop");
/* 546 */       pieces[11] = new Bishop(5, 0, 2, "Black Bishop");
/* 547 */       pieces[12] = new Pawn(2, 7, 1, "White Pawn");
/* 548 */       pieces[13] = new Pawn(5, 7, 1, "White Pawn");
/* 549 */       pieces[14] = new Pawn(0, 6, 1, "White Pawn");
/* 550 */       pieces[15] = new Pawn(1, 6, 1, "White Pawn");
/* 551 */       pieces[16] = new Pawn(2, 6, 1, "White Pawn");
/* 552 */       pieces[17] = new Pawn(3, 6, 1, "White Pawn");
/* 553 */       pieces[18] = new Pawn(4, 6, 1, "White Pawn");
/* 554 */       pieces[19] = new Pawn(5, 6, 1, "White Pawn");
/* 555 */       pieces[20] = new Pawn(6, 6, 1, "White Pawn");
/* 556 */       pieces[21] = new Pawn(7, 6, 1, "White Pawn");
/* 557 */       pieces[23] = new Pawn(0, 1, 2, "Black Pawn");
/* 558 */       pieces[24] = new Pawn(1, 1, 2, "Black Pawn");
/* 559 */       pieces[25] = new Pawn(2, 1, 2, "Black Pawn");
/* 560 */       pieces[26] = new Pawn(3, 1, 2, "Black Pawn");
/* 561 */       pieces[27] = new Pawn(4, 1, 2, "Black Pawn");
/* 562 */       pieces[28] = new Pawn(5, 1, 2, "Black Pawn");
/* 563 */       pieces[29] = new Pawn(6, 1, 2, "Black Pawn");
/* 564 */       pieces[30] = new Pawn(7, 1, 2, "Black Pawn");
/* 565 */       pieces[31] = new Queen(3, 0, 2, "Black Queen");
/*     */       
/* 567 */       pieces[22] = new Pawn(3, 7, 1, "White Pawn");
/* 568 */       pieces[32] = new Pawn(0, 4, 1, "White Pawn");
/* 569 */       pieces[33] = new Pawn(1, 4, 1, "White Pawn");
/* 570 */       pieces[34] = new Pawn(2, 4, 1, "White Pawn");
/* 571 */       pieces[35] = new Pawn(3, 4, 1, "White Pawn");
/* 572 */       pieces[36] = new Pawn(4, 4, 1, "White Pawn");
/* 573 */       pieces[37] = new Pawn(5, 4, 1, "White Pawn");
/* 574 */       pieces[38] = new Pawn(6, 4, 1, "White Pawn");
/* 575 */       pieces[39] = new Pawn(7, 4, 1, "White Pawn");
/* 576 */       pieces[40] = new Pawn(0, 5, 1, "White Pawn");
/* 577 */       pieces[41] = new Pawn(1, 5, 1, "White Pawn");
/* 578 */       pieces[42] = new Pawn(2, 5, 1, "White Pawn");
/* 579 */       pieces[43] = new Pawn(3, 5, 1, "White Pawn");
/* 580 */       pieces[44] = new Pawn(4, 5, 1, "White Pawn");
/* 581 */       pieces[45] = new Pawn(5, 5, 1, "White Pawn");
/* 582 */       pieces[46] = new Pawn(6, 5, 1, "White Pawn");
/* 583 */       pieces[47] = new Pawn(7, 5, 1, "White Pawn");
/* 584 */       break;
/*     */     
/*     */     case 5: 
/* 587 */       pieces = new ChessPiece[32];
/* 588 */       pieces[0] = new King(4, 0, 2, "Black King");
/* 589 */       pieces[1] = new King(4, 7, 1, "White King");
/* 590 */       pieces[2] = new Knight(5, 0, 2, "Black Knight");
/* 591 */       pieces[3] = new Knight(6, 0, 2, "Black Knight");
/* 592 */       pieces[4] = new Rook(0, 0, 2, "Black Rook");
/* 593 */       pieces[5] = new Rook(7, 0, 2, "Black Rook");
/* 594 */       pieces[6] = new Knight(5, 7, 1, "white Knight");
/* 595 */       pieces[7] = new Knight(6, 7, 1, "White Knight");
/* 596 */       pieces[8] = new Rook(0, 7, 1, "White Rook");
/* 597 */       pieces[9] = new Rook(7, 7, 1, "White Rook");
/* 598 */       pieces[10] = new Bishop(1, 0, 2, "Black Bishop");
/* 599 */       pieces[11] = new Bishop(2, 0, 2, "Black Bishop");
/* 600 */       pieces[12] = new Bishop(1, 7, 1, "White Bishop");
/* 601 */       pieces[13] = new Bishop(2, 7, 1, "White Bishop");
/* 602 */       pieces[14] = new Pawn(0, 6, 1, "White Pawn");
/* 603 */       pieces[15] = new Pawn(1, 6, 1, "White Pawn");
/* 604 */       pieces[16] = new Pawn(2, 6, 1, "White Pawn");
/* 605 */       pieces[17] = new Pawn(3, 6, 1, "White Pawn");
/* 606 */       pieces[18] = new Pawn(4, 6, 1, "White Pawn");
/* 607 */       pieces[19] = new Pawn(5, 6, 1, "White Pawn");
/* 608 */       pieces[20] = new Pawn(6, 6, 1, "White Pawn");
/* 609 */       pieces[21] = new Pawn(7, 6, 1, "White Pawn");
/* 610 */       pieces[23] = new Pawn(0, 1, 2, "Black Pawn");
/* 611 */       pieces[24] = new Pawn(1, 1, 2, "Black Pawn");
/* 612 */       pieces[25] = new Pawn(2, 1, 2, "Black Pawn");
/* 613 */       pieces[26] = new Pawn(3, 1, 2, "Black Pawn");
/* 614 */       pieces[27] = new Pawn(4, 1, 2, "Black Pawn");
/* 615 */       pieces[28] = new Pawn(5, 1, 2, "Black Pawn");
/* 616 */       pieces[29] = new Pawn(6, 1, 2, "Black Pawn");
/* 617 */       pieces[30] = new Pawn(7, 1, 2, "Black Pawn");
/* 618 */       pieces[31] = new Queen(3, 0, 2, "Black Queen");
/* 619 */       pieces[22] = new Queen(3, 7, 1, "White Queen");
/* 620 */       break;
/*     */     case 6: 
/* 622 */       pieces = new ChessPiece[32];
/* 623 */       pieces[1] = new King(4, 0, 1, "White King");
/* 624 */       pieces[0] = new King(4, 7, 2, "Black King");
/* 625 */       pieces[2] = new Knight(1, 0, 1, "White Knight");
/* 626 */       pieces[3] = new Knight(6, 0, 1, "White Knight");
/* 627 */       pieces[4] = new Rook(0, 0, 1, "White Rook");
/* 628 */       pieces[5] = new Rook(7, 0, 1, "White Rook");
/* 629 */       pieces[6] = new Knight(1, 7, 2, "Black Knight");
/* 630 */       pieces[7] = new Knight(6, 7, 2, "Black Knight");
/* 631 */       pieces[8] = new Rook(0, 7, 2, "Black Rook");
/* 632 */       pieces[9] = new Rook(7, 7, 2, "Black Rook");
/* 633 */       pieces[10] = new Bishop(2, 0, 1, "White Bishop");
/* 634 */       pieces[11] = new Bishop(5, 0, 1, "White Bishop");
/* 635 */       pieces[12] = new Bishop(2, 7, 2, "Black Bishop");
/* 636 */       pieces[13] = new Bishop(5, 7, 2, "Black Bishop");
/* 637 */       pieces[14] = new Pawn(0, 6, 2, "Black Pawn");
/* 638 */       pieces[15] = new Pawn(1, 6, 2, "Black Pawn");
/* 639 */       pieces[16] = new Pawn(2, 6, 2, "Black Pawn");
/* 640 */       pieces[17] = new Pawn(3, 6, 2, "Black Pawn");
/* 641 */       pieces[18] = new Pawn(4, 6, 2, "Black Pawn");
/* 642 */       pieces[19] = new Pawn(5, 6, 2, "Black Pawn");
/* 643 */       pieces[20] = new Pawn(6, 6, 2, "Black Pawn");
/* 644 */       pieces[21] = new Pawn(7, 6, 2, "Black Pawn");
/* 645 */       pieces[23] = new Pawn(0, 1, 1, "White Pawn");
/* 646 */       pieces[24] = new Pawn(1, 1, 1, "White Pawn");
/* 647 */       pieces[25] = new Pawn(2, 1, 1, "White Pawn");
/* 648 */       pieces[26] = new Pawn(3, 1, 1, "White Pawn");
/* 649 */       pieces[27] = new Pawn(4, 1, 1, "White Pawn");
/* 650 */       pieces[28] = new Pawn(5, 1, 1, "White Pawn");
/* 651 */       pieces[29] = new Pawn(6, 1, 1, "White Pawn");
/* 652 */       pieces[30] = new Pawn(7, 1, 1, "White Pawn");
/* 653 */       pieces[31] = new Queen(3, 0, 1, "White Queen");
/* 654 */       pieces[22] = new Queen(3, 7, 2, "Black Queen");
/* 655 */       break;
/*     */     case 7: 
/* 657 */       pieces = new ChessPiece[39];
/* 658 */       pieces[0] = new King(4, 0, 2, "Black King");
/* 659 */       pieces[1] = new King(4, 7, 1, "White King");
/* 660 */       pieces[2] = new Knight(1, 0, 2, "Black Knight");
/* 661 */       pieces[3] = new Knight(6, 0, 2, "Black Knight");
/* 662 */       pieces[4] = new Rook(0, 0, 2, "Black Rook");
/* 663 */       pieces[5] = new Rook(7, 0, 2, "Black Rook");
/* 664 */       pieces[6] = new Knight(1, 7, 1, "white Knight");
/* 665 */       pieces[7] = new Knight(6, 7, 1, "White Knight");
/* 666 */       pieces[8] = new Rook(0, 7, 1, "White Rook");
/* 667 */       pieces[9] = new Rook(7, 7, 1, "White Rook");
/* 668 */       pieces[10] = new Bishop(5, 0, 2, "Black Bishop");
/* 669 */       pieces[11] = new Bishop(2, 0, 2, "Black Bishop");
/* 670 */       pieces[12] = new Bishop(5, 7, 1, "White Bishop");
/* 671 */       pieces[13] = new Bishop(2, 7, 1, "White Bishop");
/* 672 */       pieces[14] = new Pawn(0, 6, 1, "White Pawn");
/* 673 */       pieces[15] = new Pawn(1, 6, 1, "White Pawn");
/* 674 */       pieces[16] = new Pawn(2, 6, 1, "White Pawn");
/* 675 */       pieces[17] = new Pawn(3, 6, 1, "White Pawn");
/* 676 */       pieces[18] = new Pawn(4, 6, 1, "White Pawn");
/* 677 */       pieces[19] = new Pawn(5, 6, 1, "White Pawn");
/* 678 */       pieces[20] = new Pawn(6, 6, 1, "White Pawn");
/* 679 */       pieces[21] = new Pawn(7, 6, 1, "White Pawn");
/* 680 */       pieces[23] = new Pawn(0, 1, 2, "Black Pawn");
/* 681 */       pieces[24] = new Pawn(1, 1, 2, "Black Pawn");
/* 682 */       pieces[25] = new Pawn(2, 1, 2, "Black Pawn");
/* 683 */       pieces[26] = new Pawn(3, 1, 2, "Black Pawn");
/* 684 */       pieces[27] = new Pawn(4, 1, 2, "Black Pawn");
/* 685 */       pieces[28] = new Pawn(5, 1, 2, "Black Pawn");
/* 686 */       pieces[29] = new Pawn(6, 1, 2, "Black Pawn");
/* 687 */       pieces[30] = new Pawn(7, 1, 2, "Black Pawn");
/* 688 */       pieces[31] = new Queen(3, 0, 2, "Black Queen");
/* 689 */       pieces[22] = new Pawn(1, 5, 1, "White Pawn");
/* 690 */       pieces[32] = new Pawn(2, 5, 1, "White Pawn");
/* 691 */       pieces[33] = new Pawn(2, 4, 1, "White Pawn");
/* 692 */       pieces[34] = new Pawn(3, 4, 1, "White Pawn");
/* 693 */       pieces[35] = new Pawn(4, 4, 1, "White Pawn");
/* 694 */       pieces[36] = new Pawn(5, 4, 1, "White Pawn");
/* 695 */       pieces[37] = new Pawn(5, 5, 1, "White Pawn");
/* 696 */       pieces[38] = new Pawn(6, 5, 1, "White Pawn");
/* 697 */       break;
/*     */     
/*     */     case 8: 
/* 700 */       pieces = new ChessPiece[15];
/* 701 */       pieces[0] = new King(4, 0, 2, "Black King");
/* 702 */       pieces[1] = new King(4, 7, 1, "White King");
/* 703 */       pieces[2] = new Knight(5, 0, 2, "Black Knight");
/* 704 */       pieces[3] = new Knight(6, 0, 2, "Black Knight");
/* 705 */       pieces[4] = new Knight(1, 0, 2, "Black Knight");
/* 706 */       pieces[5] = new Knight(2, 0, 2, "Black Knight");
/*     */       
/* 708 */       pieces[6] = new Pawn(0, 6, 1, "White Pawn");
/* 709 */       pieces[7] = new Pawn(1, 6, 1, "White Pawn");
/* 710 */       pieces[8] = new Pawn(2, 6, 1, "White Pawn");
/* 711 */       pieces[9] = new Pawn(3, 6, 1, "White Pawn");
/* 712 */       pieces[10] = new Pawn(4, 6, 1, "White Pawn");
/* 713 */       pieces[11] = new Pawn(5, 6, 1, "White Pawn");
/* 714 */       pieces[12] = new Pawn(6, 6, 1, "White Pawn");
/* 715 */       pieces[13] = new Pawn(7, 6, 1, "White Pawn");
/* 716 */       pieces[14] = new Pawn(4, 1, 2, "Black Pawn");
/*     */       
/* 718 */       break;
/*     */     case 9: 
/* 720 */       pieces = new ChessPiece[40];
/* 721 */       pieces[0] = new King(4, 0, 2, "Black King");
/* 722 */       pieces[1] = new King(4, 7, 1, "White King");
/* 723 */       pieces[2] = new Knight(1, 0, 2, "Black Knight");
/* 724 */       pieces[3] = new Knight(6, 0, 2, "Black Knight");
/* 725 */       pieces[4] = new Knight(0, 0, 2, "Black Rook");
/* 726 */       pieces[5] = new Knight(7, 0, 2, "Black Rook");
/* 727 */       pieces[6] = new Knight(1, 7, 1, "White Knight");
/* 728 */       pieces[7] = new Knight(6, 7, 1, "White Knight");
/* 729 */       pieces[8] = new Rook(0, 7, 1, "White Rook");
/* 730 */       pieces[9] = new Rook(7, 7, 1, "White Rook");
/* 731 */       pieces[10] = new Knight(2, 0, 2, "Black Knight");
/* 732 */       pieces[11] = new Knight(5, 0, 2, "Black Knight");
/* 733 */       pieces[12] = new Bishop(2, 7, 1, "White Bishop");
/* 734 */       pieces[13] = new Bishop(5, 7, 1, "White Bishop");
/* 735 */       pieces[14] = new Pawn(0, 6, 1, "White Pawn");
/* 736 */       pieces[15] = new Pawn(1, 6, 1, "White Pawn");
/* 737 */       pieces[16] = new Pawn(2, 6, 1, "White Pawn");
/* 738 */       pieces[17] = new Pawn(3, 6, 1, "White Pawn");
/* 739 */       pieces[18] = new Pawn(4, 6, 1, "White Pawn");
/* 740 */       pieces[19] = new Pawn(5, 6, 1, "White Pawn");
/* 741 */       pieces[20] = new Pawn(6, 6, 1, "White Pawn");
/* 742 */       pieces[21] = new Pawn(7, 6, 1, "White Pawn");
/* 743 */       pieces[23] = new Pawn(0, 1, 2, "Black Pawn");
/* 744 */       pieces[24] = new Pawn(1, 1, 2, "Black Pawn");
/* 745 */       pieces[25] = new Pawn(2, 1, 2, "Black Pawn");
/* 746 */       pieces[26] = new Pawn(3, 1, 2, "Black Pawn");
/* 747 */       pieces[27] = new Pawn(4, 1, 2, "Black Pawn");
/* 748 */       pieces[28] = new Pawn(5, 1, 2, "Black Pawn");
/* 749 */       pieces[29] = new Pawn(6, 1, 2, "Black Pawn");
/* 750 */       pieces[30] = new Pawn(7, 1, 2, "Black Pawn");
/* 751 */       pieces[31] = new Knight(3, 0, 2, "Black Knight");
/* 752 */       pieces[22] = new Queen(3, 7, 1, "White Queen");
/* 753 */       pieces[32] = new Pawn(2, 2, 2, "Black Pawn");
/* 754 */       pieces[33] = new Pawn(1, 3, 2, "Black Pawn");
/* 755 */       pieces[34] = new Pawn(2, 3, 2, "Black Pawn");
/* 756 */       pieces[35] = new Pawn(3, 3, 2, "Black Pawn");
/* 757 */       pieces[36] = new Pawn(4, 3, 2, "Black Pawn");
/* 758 */       pieces[37] = new Pawn(5, 3, 2, "Black Pawn");
/* 759 */       pieces[38] = new Pawn(6, 3, 2, "Black Pawn");
/* 760 */       pieces[39] = new Pawn(5, 2, 2, "Black Pawn");
/*     */     }
/*     */     
/* 763 */     gameStarted = true;
/* 764 */     selected = -1;
/* 765 */     Chess.game.refresh();
/*     */   }
/*     */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\GameLogic\GameBoard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */