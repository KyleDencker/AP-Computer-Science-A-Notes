/*    */ package GameLogic;
/*    */ 
/*    */ import graphics.menu;
/*    */ import java.awt.Point;
/*    */ import java.io.IOException;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Chess
/*    */ {
/* 15 */   public static boolean debug = false;
/*    */   public static Chess game;
/*    */   public static GameBoard board;
/* 18 */   public static String verison = "0.5.3.0";
/*    */   
/*    */   private JFrame window;
/*    */   
/*    */   public Chess()
/*    */     throws IOException
/*    */   {
/* 25 */     this.window = new JFrame("Chess");
/*    */     
/* 27 */     this.window.setDefaultCloseOperation(3);
/* 28 */     this.window.setJMenuBar(menu.MainMenuBar());
/* 29 */     board = new GameBoard();
/* 30 */     this.window.add(board);
/* 31 */     this.window.setVisible(true);
/* 32 */     this.window.setSize(405, 450);
/* 33 */     this.window.setResizable(false);
/* 34 */     GameMode.setDefaultGame();
/*    */   }
/*    */   
/*    */   public void close() {
/* 38 */     this.window.dispose();
/* 39 */     System.exit(1);
/*    */   }
/*    */   
/*    */   public void refresh() {
/* 43 */     this.window.repaint();
/*    */   }
/*    */   
/*    */ 
/*    */   public void changeSize(int mode)
/*    */   {
/* 49 */     switch (mode) {
/*    */     case 1: 
/*    */     case 4: 
/*    */     case 5: 
/*    */     case 6: 
/*    */     case 7: 
/*    */     case 8: 
/*    */     case 9: 
/* 57 */       this.window.setBounds(this.window.getLocation().x, this.window.getLocation().y, 405, 450);
/* 58 */       break;
/*    */     case 2: 
/* 60 */       this.window.setBounds(this.window.getLocation().x, this.window.getLocation().y, 505, 550);
/* 61 */       break;
/*    */     case 3: 
/* 63 */       this.window.setBounds(this.window.getLocation().x, this.window.getLocation().y, 405, 750);
/*    */     }
/*    */     
/*    */   }
/*    */   
/*    */   public static void main(String[] args)
/*    */     throws IOException
/*    */   {
/* 71 */     game = new Chess();
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\GameLogic\Chess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */