/*    */ package GameLogic;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class GameMode {
/*    */   private static int x;
/*    */   private static int y;
/*    */   private static int mode;
/*    */   private static String modeName;
/*    */   
/* 11 */   public static void changeMode(int value) throws IOException { Chess.game.changeSize(value);
/* 12 */     switch (value) {
/*    */     case 1: 
/* 14 */       x = 8;
/* 15 */       y = 8;
/* 16 */       mode = 1;
/* 17 */       modeName = "Standard Chess";
/*    */       
/* 19 */       break;
/*    */     case 2: 
/* 21 */       x = 10;
/* 22 */       y = 10;
/* 23 */       mode = 2;
/* 24 */       modeName = "Big Bang Theory Chess";
/* 25 */       break;
/*    */     case 3: 
/* 27 */       x = 8;
/* 28 */       y = 14;
/* 29 */       mode = 3;
/* 30 */       modeName = "Dencker Chess";
/* 31 */       break;
/*    */     case 4: 
/* 33 */       x = 8;
/* 34 */       y = 8;
/* 35 */       mode = 4;
/* 36 */       modeName = "Horde Chess";
/* 37 */       break;
/*    */     case 5: 
/* 39 */       x = 8;
/* 40 */       y = 8;
/* 41 */       mode = 5;
/* 42 */       modeName = "Displacement Chess";
/* 43 */       break;
/*    */     case 6: 
/* 45 */       x = 8;
/* 46 */       y = 8;
/* 47 */       mode = 6;
/* 48 */       modeName = "Backwards Chess";
/* 49 */       break;
/*    */     case 7: 
/* 51 */       x = 8;
/* 52 */       y = 8;
/* 53 */       mode = 7;
/* 54 */       modeName = "Pawns Game";
/* 55 */       break;
/*    */     case 8: 
/* 57 */       x = 8;
/* 58 */       y = 8;
/* 59 */       mode = 8;
/* 60 */       modeName = "Peasant's Revolt";
/* 61 */       break;
/*    */     case 9: 
/* 63 */       x = 8;
/* 64 */       y = 8;
/* 65 */       mode = 9;
/* 66 */       modeName = "Week!";
/*    */     }
/*    */     
/*    */     
/* 70 */     GameBoard.newGame(mode);
/*    */   }
/*    */   
/*    */   public static int getX()
/*    */   {
/* 75 */     return x;
/*    */   }
/*    */   
/*    */   public static int getY() {
/* 79 */     return y;
/*    */   }
/*    */   
/*    */   public static int getMode() {
/* 83 */     return mode;
/*    */   }
/*    */   
/*    */   public static String getModeName() {
/* 87 */     return modeName;
/*    */   }
/*    */   
/*    */   public static void setDefaultGame() {
/* 91 */     x = 8;
/* 92 */     y = 8;
/* 93 */     mode = 1;
/* 94 */     modeName = "Standard Chess";
/*    */   }
/*    */   
/*    */   public static boolean isInBounds(int xValue, int yValue) {
/* 98 */     if ((xValue < x) && (xValue > -1) && (yValue < y) && (yValue > -1)) return true;
/* 99 */     return false;
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\GameLogic\GameMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */