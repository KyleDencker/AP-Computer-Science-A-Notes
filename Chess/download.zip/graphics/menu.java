/*     */ package graphics;
/*     */ 
/*     */ import GameLogic.Actions;
/*     */ import GameLogic.MenuActions;
/*     */ import javax.accessibility.AccessibleContext;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JRadioButtonMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class menu
/*     */ {
/*     */   public static JMenuBar MainMenuBar()
/*     */   {
/*  24 */     JMenuBar menuBar = new JMenuBar();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  29 */     JMenu menu = new JMenu("File");
/*  30 */     menu.setMnemonic(65);
/*  31 */     menu.getAccessibleContext().setAccessibleDescription(
/*  32 */       "Creates, saves, and opens games.");
/*  33 */     menuBar.add(menu);
/*     */     
/*  35 */     JMenuItem menuItem = new JMenuItem("New Game", 78);
/*  36 */     menuItem.setAccelerator(KeyStroke.getKeyStroke(
/*  37 */       78, 2));
/*  38 */     menuItem.addActionListener(new Actions());
/*  39 */     menu.add(menuItem);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */     menu.addSeparator();
/*     */     
/*  54 */     menuItem = new JMenuItem("Close");
/*  55 */     menuItem.setAccelerator(KeyStroke.getKeyStroke(115, 8));
/*  56 */     menuItem.addActionListener(new Actions());
/*  57 */     menu.add(menuItem);
/*     */     
/*     */ 
/*  60 */     menu = new JMenu("Game Mode");
/*  61 */     menu.addMenuListener(new MenuActions(2));
/*     */     
/*  63 */     menu.setMnemonic(71);
/*  64 */     menu.getAccessibleContext().setAccessibleDescription(
/*  65 */       "Changes the game mode");
/*  66 */     menuBar.add(menu);
/*     */     
/*     */ 
/*  69 */     ButtonGroup group = new ButtonGroup();
/*     */     
/*  71 */     JRadioButtonMenuItem rbMenuItem = new JRadioButtonMenuItem("Standard Chess");
/*  72 */     rbMenuItem.setSelected(true);
/*     */     
/*  74 */     rbMenuItem.addActionListener(new Actions());
/*  75 */     group.add(rbMenuItem);
/*  76 */     menu.add(rbMenuItem);
/*     */     
/*     */ 
/*     */ 
/*  80 */     rbMenuItem = new JRadioButtonMenuItem("Backwards Chess");
/*  81 */     rbMenuItem.setSelected(false);
/*  82 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/*  84 */     group.add(rbMenuItem);
/*  85 */     menu.add(rbMenuItem);
/*     */     
/*  87 */     rbMenuItem = new JRadioButtonMenuItem("Displacement Chess");
/*  88 */     rbMenuItem.setSelected(false);
/*  89 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/*  91 */     group.add(rbMenuItem);
/*  92 */     menu.add(rbMenuItem);
/*     */     
/*  94 */     rbMenuItem = new JRadioButtonMenuItem("Horde Chess");
/*  95 */     rbMenuItem.setSelected(false);
/*  96 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/*  98 */     group.add(rbMenuItem);
/*  99 */     menu.add(rbMenuItem);
/*     */     
/* 101 */     rbMenuItem = new JRadioButtonMenuItem("Pawns Game");
/* 102 */     rbMenuItem.setSelected(false);
/* 103 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/* 105 */     group.add(rbMenuItem);
/* 106 */     menu.add(rbMenuItem);
/*     */     
/* 108 */     rbMenuItem = new JRadioButtonMenuItem("Peasant's Revolt");
/* 109 */     rbMenuItem.setSelected(false);
/* 110 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/* 112 */     group.add(rbMenuItem);
/* 113 */     menu.add(rbMenuItem);
/*     */     
/* 115 */     rbMenuItem = new JRadioButtonMenuItem("Weak!");
/* 116 */     rbMenuItem.setSelected(false);
/* 117 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/* 119 */     group.add(rbMenuItem);
/* 120 */     menu.add(rbMenuItem);
/*     */     
/*     */ 
/*     */ 
/* 124 */     rbMenuItem = new JRadioButtonMenuItem("Keylay's Castle");
/* 125 */     rbMenuItem.setSelected(false);
/* 126 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/* 128 */     group.add(rbMenuItem);
/* 129 */     menu.add(rbMenuItem);
/*     */     
/*     */ 
/*     */ 
/* 133 */     rbMenuItem = new JRadioButtonMenuItem("Serpant-Old Lady");
/* 134 */     rbMenuItem.setSelected(false);
/* 135 */     rbMenuItem.addActionListener(new Actions());
/*     */     
/* 137 */     group.add(rbMenuItem);
/* 138 */     menu.add(rbMenuItem);
/*     */     
/* 140 */     menu = new JMenu("Online");
/* 141 */     menu.addMenuListener(new MenuActions());
/* 142 */     menu.setMnemonic(79);
/* 143 */     menu.getAccessibleContext().setAccessibleDescription(
/* 144 */       "Online Options");
/* 145 */     menuBar.add(menu);
/*     */     
/* 147 */     menuItem = new JMenuItem("Host Game", 72);
/* 148 */     menuItem.setAccelerator(KeyStroke.getKeyStroke(
/* 149 */       72, 2));
/* 150 */     menuItem.addActionListener(new Actions());
/* 151 */     menu.add(menuItem);
/*     */     
/* 153 */     menuItem = new JMenuItem("Join Game", 74);
/* 154 */     menuItem.setAccelerator(KeyStroke.getKeyStroke(74, 2));
/* 155 */     menuItem.addActionListener(new Actions());
/* 156 */     menu.add(menuItem);
/*     */     
/* 158 */     menu.addSeparator();
/*     */     
/* 160 */     menuItem = new JMenuItem("Disconnect", 74);
/*     */     
/* 162 */     menuItem.addActionListener(new Actions());
/* 163 */     menu.add(menuItem);
/*     */     
/* 165 */     menu = new JMenu("Help");
/* 166 */     menu.setMnemonic(72);
/* 167 */     menu.getAccessibleContext().setAccessibleDescription(
/* 168 */       "Online Options");
/* 169 */     menuBar.add(menu);
/*     */     
/* 171 */     menuItem = new JMenuItem("Display IP", 73);
/* 172 */     menuItem.setAccelerator(KeyStroke.getKeyStroke(
/* 173 */       72, 2));
/* 174 */     menuItem.addActionListener(new Actions());
/* 175 */     menu.add(menuItem);
/*     */     
/* 177 */     menuItem = new JMenuItem("About", 65);
/* 178 */     menuItem.setAccelerator(KeyStroke.getKeyStroke(74, 2));
/* 179 */     menuItem.addActionListener(new Actions());
/* 180 */     menu.add(menuItem);
/*     */     
/* 182 */     return menuBar;
/*     */   }
/*     */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\graphics\menu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */