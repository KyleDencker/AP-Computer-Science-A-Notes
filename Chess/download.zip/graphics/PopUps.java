/*    */ package graphics;
/*    */ 
/*    */ import GameLogic.GameBoard;
/*    */ import GameLogic.GameMode;
/*    */ import NET.Server;
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PopUps
/*    */ {
/*    */   public static void newGame()
/*    */     throws IOException
/*    */   {
/* 19 */     if (JOptionPane.showConfirmDialog(new JFrame(), 
/* 20 */       "If start a new game, all unsaved information will be lost.\n\nWould you like start a new game?", 
/* 21 */       "New Game", 
/* 22 */       0) == 0) {
/* 23 */       GameBoard.newGame(GameMode.getMode());
/*    */     }
/*    */   }
/*    */   
/*    */   public static void displayIP() {
/*    */     try {
/* 29 */       InetAddress thisIp = InetAddress.getLocalHost();
/* 30 */       String message = "Your IP Address is: " + thisIp.getHostAddress();
/* 31 */       JOptionPane.showMessageDialog(new JFrame(), message, "IP Address", 2);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 35 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void openGame()
/*    */   {
/* 43 */     String message = "This feature has not been created yet.";
/* 44 */     JOptionPane.showMessageDialog(new JFrame(), message, "Error:  Not a feature... yet", 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void saveGame()
/*    */   {
/* 51 */     String message = "This feature has not been created yet.";
/* 52 */     JOptionPane.showMessageDialog(new JFrame(), message, "Error:  Not a feature... yet", 0);
/*    */   }
/*    */   
/*    */ 
/*    */   public static void GameMode(int mode)
/*    */     throws IOException
/*    */   {
/* 59 */     if (JOptionPane.showConfirmDialog(new JFrame(), 
/* 60 */       "You are about to change the game mode.   This will cause the current game data to be lost.\n\nWould you like start a new game?", 
/* 61 */       "Change Game Mode", 
/* 62 */       0) == 0) {
/* 63 */       if (GameBoard.server != null) {
/* 64 */         GameBoard.server.sendMessage("NG " + mode);
/*    */       }
/* 66 */       GameMode.changeMode(mode);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void check() {
/* 71 */     String message = "Check!";
/* 72 */     JOptionPane.showMessageDialog(new JFrame(), message, "Check!", 2);
/*    */   }
/*    */   
/*    */   public static void KingInCheck()
/*    */   {
/* 77 */     String message = "You cannot place your king in check!";
/* 78 */     JOptionPane.showMessageDialog(new JFrame(), message, "Check!", 2);
/*    */   }
/*    */   
/*    */   public static void checkMate()
/*    */   {
/* 83 */     String message = "Checkmate!";
/* 84 */     JOptionPane.showMessageDialog(new JFrame(), message, "Checkmate!", 0);
/*    */   }
/*    */   
/*    */   public static void poison(String name) {
/* 88 */     String message = "The " + name + " died of poison.";
/* 89 */     JOptionPane.showMessageDialog(new JFrame(), message, "Piece Death", 0);
/*    */   }
/*    */   
/*    */   public static void errorMessage(String message) {
/* 93 */     JOptionPane.showMessageDialog(new JFrame(), message, "Ops...  There is a problem", 0);
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\graphics\PopUps.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */