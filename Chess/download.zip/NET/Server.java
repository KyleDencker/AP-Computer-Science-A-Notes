/*     */ package NET;
/*     */ 
/*     */ import GameLogic.Chess;
/*     */ import GameLogic.GameBoard;
/*     */ import GameLogic.GameMode;
/*     */ import graphics.PopUps;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.Scanner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Server
/*     */   implements Runnable
/*     */ {
/*     */   private ServerSocket serverSocket;
/*     */   private Socket clientSocket;
/*     */   private Thread t;
/*  49 */   private boolean disconnecting = false;
/*  50 */   public static boolean connected = false;
/*     */   
/*     */   public Server() {
/*  53 */     GameBoard.isOnline = true;
/*  54 */     this.t = new Thread(this);
/*     */     
/*  56 */     this.t.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/*  63 */     connected = false;
/*  64 */     GameBoard.isOnline = false;
/*     */     
/*     */     try
/*     */     {
/*  68 */       if (this.clientSocket != null) {
/*  69 */         sendMessage("CloseGame");
/*  70 */         this.disconnecting = true;
/*  71 */         this.clientSocket.close();
/*  72 */         this.clientSocket = null;
/*     */       }
/*  74 */       this.serverSocket.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */   public void run() {
/*  80 */     IPAddress ip = new IPAddress();
/*     */     
/*  82 */     this.serverSocket = null;
/*     */     try {
/*  84 */       this.serverSocket = new ServerSocket(5239);
/*     */     } catch (IOException e) {
/*  86 */       PopUps.errorMessage("Could not setup the server. \n\nPlease check to make sure no other process is using 5239.");
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     this.clientSocket = null;
/*     */     try {
/*  92 */       this.clientSocket = this.serverSocket.accept();
/*     */     } catch (IOException e) {
/*  94 */       PopUps.errorMessage("The server has been shut off.");
/*  95 */       return;
/*     */     }
/*     */     try {
/*  98 */       GameBoard.newGame(GameMode.getMode());
/*     */     } catch (IOException e) {
/* 100 */       PopUps.errorMessage("Could not create a new game");
/* 101 */       return;
/*     */     }
/* 103 */     connected = true;
/* 104 */     GameBoard.isOnline = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 111 */       PrintWriter out = new PrintWriter(this.clientSocket.getOutputStream(), true);
/* 112 */       BufferedReader in = new BufferedReader(
/* 113 */         new InputStreamReader(
/* 114 */         this.clientSocket.getInputStream()));
/*     */       
/* 116 */       sendMessage(Chess.verison);
/* 117 */       String inputLine = in.readLine();
/* 118 */       if (!inputLine.equals(Chess.verison)) {
/* 119 */         PopUps.errorMessage("The versions do not match.");
/* 120 */         connected = false;
/* 121 */         GameBoard.isOnline = false;
/* 122 */         this.clientSocket.close();
/* 123 */         this.serverSocket.close();
/* 124 */         return;
/*     */       }
/* 126 */       String outputLine = GameMode.getMode();
/* 127 */       sendMessage(outputLine);
/*     */     }
/*     */     catch (IOException e1) {
/* 130 */       PopUps.errorMessage("Unknown error"); return;
/*     */     }
/*     */     
/*     */     do
/*     */     {
/*     */       try
/*     */       {
/*     */         String outputLine;
/*     */         String inputLine;
/* 139 */         PrintWriter out = new PrintWriter(this.clientSocket.getOutputStream(), true);
/* 140 */         BufferedReader in = new BufferedReader(
/* 141 */           new InputStreamReader(
/* 142 */           this.clientSocket.getInputStream()));
/* 143 */         while ((inputLine = in.readLine()) != null)
/*     */         {
/* 145 */           if (inputLine.equals("CloseGame")) {
/* 146 */             connected = false;
/* 147 */             GameBoard.isOnline = false;
/* 148 */             this.clientSocket.close();
/* 149 */             this.serverSocket.close();
/* 150 */             PopUps.errorMessage("The black has disconnected from you. \nYou win!");
/* 151 */             return;
/*     */           }
/*     */           
/* 154 */           if (GameBoard.turn == 2)
/*     */           {
/* 156 */             Scanner scan = new Scanner(inputLine);
/*     */             
/* 158 */             Chess.board.chessMove(scan.nextInt(), scan.nextInt());
/*     */             
/* 160 */             if (inputLine.equals("Checkmate")) {
/* 161 */               connected = false;
/* 162 */               GameBoard.isOnline = false;
/* 163 */               this.clientSocket.close();
/* 164 */               this.serverSocket.close();
/* 165 */               return;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 175 */         connected = false;
/* 176 */         GameBoard.isOnline = false;
/* 177 */         if (!this.disconnecting) {
/* 178 */           PopUps.errorMessage("Client Disconnected from the game.");
/*     */         } else
/* 180 */           PopUps.errorMessage("You have disconnected from the game.");
/* 181 */         return;
/*     */       }
/* 134 */     } while (connected);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 193 */       this.clientSocket.close();
/* 194 */       this.serverSocket.close();
/*     */     }
/*     */     catch (IOException e) {
/* 197 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public void sendMessage(String message) throws IOException
/*     */   {
/* 203 */     PrintWriter out = new PrintWriter(this.clientSocket.getOutputStream(), true);
/* 204 */     out.println(message);
/* 205 */     System.out.println("Server: " + message);
/*     */   }
/*     */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\NET\Server.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */