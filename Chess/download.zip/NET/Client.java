/*     */ package NET;
/*     */ 
/*     */ import GameLogic.Chess;
/*     */ import GameLogic.GameBoard;
/*     */ import GameLogic.GameMode;
/*     */ import graphics.PopUps;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Scanner;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Client
/*     */   implements Runnable
/*     */ {
/*  47 */   private Socket kkSocket = null;
/*     */   private Thread t;
/*  49 */   private boolean disconnecting = false;
/*     */   
/*  51 */   public static boolean connected = false;
/*     */   
/*     */   public Client() {
/*     */     try {
/*  55 */       String ip = JOptionPane.showInputDialog(null, 
/*  56 */         "Enter the IP address you would like to connect to: ", 
/*  57 */         "Connect to User", 1);
/*  58 */       if (ip != null) {
/*  59 */         this.kkSocket = new Socket(ip, 5239);
/*  60 */         BufferedReader in = new BufferedReader(new InputStreamReader(this.kkSocket.getInputStream()));
/*  61 */         Scanner scan = new Scanner(in.readLine());
/*  62 */         sendMessage(Chess.verison);
/*     */         
/*  64 */         if (!scan.nextLine().equals(Chess.verison)) {
/*  65 */           PopUps.errorMessage("The server you are trying to connect to does not have the same version");
/*  66 */           connected = false;
/*  67 */           GameBoard.isOnline = false;
/*  68 */           this.kkSocket.close();
/*  69 */           return;
/*     */         }
/*  71 */         scan = new Scanner(in.readLine());
/*  72 */         GameMode.changeMode(scan.nextInt());
/*  73 */         GameBoard.newGame(GameMode.getMode());
/*  74 */         connected = true;
/*  75 */         GameBoard.isOnline = true;
/*  76 */         this.t = new Thread(this);
/*  77 */         this.t.start();
/*     */       }
/*     */     }
/*     */     catch (UnknownHostException e)
/*     */     {
/*  82 */       PopUps.errorMessage("Invalid IP/Computer name.");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  86 */       PopUps.errorMessage("Could not find the server.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/*  95 */     this.disconnecting = true;
/*  96 */     connected = false;
/*  97 */     GameBoard.isOnline = false;
/*     */     try
/*     */     {
/* 100 */       sendMessage("CloseGame");
/* 101 */       this.kkSocket.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*     */     try {
/* 109 */       PrintWriter out = null;
/* 110 */       BufferedReader in = null;
/*     */       
/* 112 */       out = new PrintWriter(this.kkSocket.getOutputStream(), true);
/*     */       
/* 114 */       in = new BufferedReader(new InputStreamReader(this.kkSocket.getInputStream()));
/*     */       
/*     */ 
/*     */       String inputLine;
/*     */       
/* 119 */       while ((inputLine = in.readLine()) != null) { String inputLine;
/* 120 */         boolean action = true;
/* 121 */         if (inputLine.substring(0, 2).equals("NG")) {
/* 122 */           Scanner scan = new Scanner(inputLine.substring(2));
/* 123 */           GameMode.changeMode(scan.nextInt());
/* 124 */           GameBoard.newGame(GameMode.getMode());
/* 125 */           action = false;
/*     */         }
/* 127 */         System.out.println("Test: " + inputLine.substring(0, 1));
/*     */         
/* 129 */         if ((inputLine.equals("CloseGame")) && (action)) {
/* 130 */           connected = false;
/* 131 */           GameBoard.isOnline = false;
/* 132 */           this.kkSocket.close();
/* 133 */           PopUps.errorMessage("The white has disconnected from you. \nYou win!");
/* 134 */           return;
/*     */         }
/* 136 */         if ((GameBoard.turn == 1) && (action)) {
/* 137 */           System.out.println("Server: " + inputLine);
/* 138 */           Scanner scan = new Scanner(inputLine);
/* 139 */           if (inputLine.equals("Checkmate")) {
/* 140 */             connected = false;
/* 141 */             GameBoard.isOnline = false;
/* 142 */             this.kkSocket.close();
/* 143 */             return;
/*     */           }
/*     */           
/*     */ 
/* 147 */           Chess.board.chessMove(scan.nextInt(), scan.nextInt());
/*     */ 
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */ 
/* 158 */       connected = false;
/* 159 */       GameBoard.isOnline = false;
/* 160 */       if (!this.disconnecting) {
/* 161 */         PopUps.errorMessage("Server disconnected from the game.");
/*     */       } else {
/* 163 */         PopUps.errorMessage("You have disconnected from the game.");
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 168 */         this.kkSocket.close();
/*     */       }
/*     */       catch (IOException localIOException1) {}
/*     */       
/*     */ 
/* 173 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */   public void sendMessage(String message)
/*     */     throws IOException
/*     */   {
/* 180 */     PrintWriter out = new PrintWriter(this.kkSocket.getOutputStream(), true);
/* 181 */     out.println(message);
/* 182 */     System.out.println("Client: " + message);
/*     */   }
/*     */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\NET\Client.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */