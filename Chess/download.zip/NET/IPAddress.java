/*    */ package NET;
/*    */ 
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IPAddress
/*    */   implements Runnable
/*    */ {
/*    */   public static JFrame frame;
/*    */   
/*    */   public IPAddress()
/*    */   {
/* 16 */     Thread t = new Thread(this);
/* 17 */     t.start();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void run() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public static void main(String[] arg)
/*    */   {
/* 28 */     IPAddress ip = new IPAddress();
/*    */   }
/*    */ }


/* Location:              T:\business\dencker\Archive\CSEdWeek\ChessOpt0.5.3\!\NET\IPAddress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */